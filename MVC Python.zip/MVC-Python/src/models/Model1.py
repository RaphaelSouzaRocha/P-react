import mysql.connector


"""
    Model description
"""
class Model1:
    def __init__(self):
        pass