from flask import Flask, request, jsonify, make_response
import json

tasks = [
    {
        'id': 1,
        'name': "task1",
        "description": "This is task 1"
    },
    {
        "id": 2,
        "name": "task2",
        "description": "This is task 2"
    },
    {
        "id": 3,
        "name": "task3",
        "description": "This is task 3"
    }
]

tasksJSON = json.dumps(tasks)

class Model():

    def jsonReturn():
        return tasksJSON

    def soma():
        return '10'